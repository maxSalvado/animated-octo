from fastapi import FastAPI
from contextlib import asynccontextmanager
import httpx
from httpx import Timeout
from core.config import settings
from api.routes import misc, spreadsheet, integrations

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Shared HTTP client for third-party API (only if env present)
    client = None
    if settings.API_BASE_PATH and settings.AUTH_TOKEN:
        client = httpx.AsyncClient(
            base_url=settings.API_BASE_PATH.rstrip("/"),
            timeout=Timeout(10.0, read=30.0),
            headers={
                "Authorization": f"Bearer {settings.AUTH_TOKEN}",
                "Accept": "*/*",
                "Content-Type": "application/json",
            },
        )
    app.state.http_client = client
    try:
        yield
    finally:
        if app.state.http_client:
            await app.state.http_client.aclose()

app = FastAPI(title="Link Automation API", version="0.6.0", lifespan=lifespan)

# Register routers
app.include_router(misc.router)
app.include_router(spreadsheet.router)
app.include_router(integrations.router)
