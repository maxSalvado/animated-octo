import pandas as pd
from typing import Dict, Union, IO
from pandas import DataFrame
from io import BytesIO

def read_excel_multi(src: Union[str, bytes, IO[bytes]]) -> Dict[str, DataFrame]:
    """Read all sheets from an .xlsx into a dict: {sheet_name: DataFrame}.
    Accepts a path (str), raw bytes, or a file-like object."""
    if isinstance(src, (bytes, bytearray)):
        fh = BytesIO(src)
        x = pd.read_excel(fh, sheet_name=None, engine="openpyxl")
    elif hasattr(src, "read"):
        x = pd.read_excel(src, sheet_name=None, engine="openpyxl")
    else:
        x = pd.read_excel(src, sheet_name=None, engine="openpyxl")

    # Normalize column names: strip whitespace
    norm: Dict[str, DataFrame] = {}
    for name, df in x.items():
        df2 = df.copy()
        df2.columns = [str(c).strip() for c in df2.columns]
        norm[name] = df2
    return norm
