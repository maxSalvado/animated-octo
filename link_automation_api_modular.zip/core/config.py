from pydantic import BaseSettings
from functools import cached_property

class Settings(BaseSettings):
    # Template & spreadsheet rules
    B_TEMPLATE_PATH: str = "./templates/file_f.xlsx"
    TARGET_SHEET_NAME: str = "Deployment Report"
    TARGET_START_ROW: int = 9
    SOURCE_START_ROW: int = 7

    # Required source cols (letters) and mapping target->source
    REQUIRED_COLS_STR: str = "B,C,D,E,F,H,I,J,K,L,M,N"
    COLUMN_MAP_STR: str = "A:B,B:E,C:D,D:C,W:O"

    # Third-party API
    API_BASE_PATH: str = ""
    AUTH_TOKEN: str = ""

    class Config:
        env_file = ".env"
        case_sensitive = False

    @cached_property
    def REQUIRED_COLS(self):
        return [c.strip() for c in self.REQUIRED_COLS_STR.split(",") if c.strip()]

    @cached_property
    def COLUMN_MAP(self):
        pairs = [p for p in self.COLUMN_MAP_STR.split(",") if ":" in p]
        out = {}
        for p in pairs:
            t, s = p.split(":", 1)
            out[t.strip()] = s.strip()
        return out

settings = Settings()
