from fastapi import APIRouter

router = APIRouter(tags=["misc"])

@router.get("/healthz")
def healthz():
    return {"status": "ok"}
