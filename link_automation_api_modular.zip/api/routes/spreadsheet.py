from fastapi import APIRouter, HTTPException, UploadFile, File
from fastapi.responses import FileResponse
from typing import Any, Dict, List
from pathlib import Path
from io import BytesIO
from openpyxl import load_workbook
from openpyxl.utils import column_index_from_string
from core.config import settings
from service.ingest import read_excel_multi
import time

router = APIRouter(tags=["spreadsheets"])

def _is_blank(v: Any) -> bool:
    return v is None or (isinstance(v, str) and v.strip() == "") or (not isinstance(v, str) and str(v).strip() == "")

@router.post("/upload-extract")
async def upload_extract(file: UploadFile = File(...), limit: int = 50):
    allowed = {
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/octet-stream"
    }
    if file.content_type not in allowed:
        raise HTTPException(415, f"Unsupported content type: {file.content_type}. Please upload a .xlsx file.")

    raw = await file.read()
    if len(raw) > 25 * 1024 * 1024:
        raise HTTPException(413, "File too large (25MB max).")

    sheets = read_excel_multi(raw)
    data_preview, columns = {}, {}
    for name, df in sheets.items():
        columns[name] = [str(c) for c in df.columns]
        preview = df.head(limit).fillna("").astype(str).to_dict(orient="records")
        data_preview[name] = preview
    return {"sheets_found": list(sheets.keys()), "columns": columns, "data_preview": data_preview}

@router.post("/upload-map-template")
async def upload_map_template(file: UploadFile = File(...)):
    """
    Strict validation over REQUIRED_COLS starting at SOURCE_START_ROW:
      - If a row has ANY required value but not ALL -> 422 with details (no file generated).
      - If no required data at all -> 422.
      - Only if ALL rows with data are complete -> map COLUMN_MAP and write to template.
    """
    allowed = {
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/octet-stream"
    }
    if file.content_type not in allowed:
        raise HTTPException(415, f"Unsupported content type: {file.content_type}. Please upload a .xlsx file.")

    raw = await file.read()
    if len(raw) > 25 * 1024 * 1024:
        raise HTTPException(413, "File too large (25MB max).")

    # Load template
    template_path = settings.B_TEMPLATE_PATH
    if not template_path or not Path(template_path).exists():
        raise HTTPException(500, f"Template path not found: {template_path!r}")

    ext = Path(template_path).suffix.lower()
    keep_vba = ext in (".xlsm", ".xltm")
    wb_tmpl = load_workbook(template_path, data_only=False, keep_vba=keep_vba, keep_links=True, read_only=False)
    wb_tmpl.template = False
    if settings.TARGET_SHEET_NAME not in wb_tmpl.sheetnames:
        raise HTTPException(500, f"Template sheet '{settings.TARGET_SHEET_NAME}' not found.")
    ws_tmpl = wb_tmpl[settings.TARGET_SHEET_NAME]

    # Load source (coords mode)
    wb_src = load_workbook(BytesIO(raw), data_only=True, keep_links=True, read_only=True)
    src_ws = wb_src[wb_src.sheetnames[0]]

    # Column indices
    req_idx = {c: column_index_from_string(c) for c in settings.REQUIRED_COLS}
    map_src_idx = {tgt: column_index_from_string(src) for tgt, src in settings.COLUMN_MAP.items()}
    map_tgt_idx = {tgt: column_index_from_string(tgt) for tgt in settings.COLUMN_MAP.keys()}

    start_row = settings.SOURCE_START_ROW
    max_row = src_ws.max_row or start_row

    any_required_seen = False
    valid_rows: List[int] = []
    rows_with_missing: List[Dict[str, Any]] = []

    # Strict validation
    for r in range(start_row, max_row + 1):
        vals = {col: src_ws.cell(row=r, column=req_idx[col]).value for col in settings.REQUIRED_COLS}
        all_blank = all(_is_blank(v) for v in vals.values())
        if all_blank:
            continue

        any_required_seen = True
        missing = [col for col, v in vals.items() if _is_blank(v)]
        if missing:
            rows_with_missing.append({"row": r, "missing_required_columns": missing})
        else:
            valid_rows.append(r)

    if not any_required_seen:
        raise HTTPException(
            422,
            detail={
                "message": f"No data found in required columns starting at row {settings.SOURCE_START_ROW}.",
                "required_columns": settings.REQUIRED_COLS,
                "first_data_row": settings.SOURCE_START_ROW,
            },
        )

    if rows_with_missing:
        raise HTTPException(
            422,
            detail={
                "message": "Some rows have missing required fields. Please correct and re-upload.",
                "required_columns": settings.REQUIRED_COLS,
                "first_data_row": settings.SOURCE_START_ROW,
                "rows_with_missing_required": rows_with_missing,
            },
        )

    if not valid_rows:
        raise HTTPException(422, "No fully valid rows found after validation.")

    # Write mapped rows
    out_row = settings.TARGET_START_ROW
    for r in valid_rows:
        for tgt_col_letter, src_col_letter in settings.COLUMN_MAP.items():
            tgt_col_idx = map_tgt_idx[tgt_col_letter]
            src_col_idx = map_src_idx[tgt_col_letter]
            val = src_ws.cell(row=r, column=src_col_idx).value
            ws_tmpl.cell(row=out_row, column=tgt_col_idx, value=val)
        out_row += 1

    # Recalc & save
    try:
        wb_tmpl.calculation.fullCalcOnLoad = True
    except Exception:
        pass
    try:
        ws_tmpl.calculate_dimension(force=True)
    except Exception:
        pass

    out_dir = Path("./out"); out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"mapped_{int(time.time())}.xlsx"
    wb_tmpl.save(out_path)

    return FileResponse(
        str(out_path),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        filename=out_path.name
    )
