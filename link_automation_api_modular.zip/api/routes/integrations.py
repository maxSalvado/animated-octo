from fastapi import APIRouter, Body, HTTPException, Response, Depends
import httpx
from httpx import ReadTimeout
from core.config import settings
from core.deps import get_http_client
from typing import Any, Dict, Optional

router = APIRouter(tags=["integrations"])

@router.post("/fetch-details__test")
async def fetch_details__test(
    payload: Optional[Dict[str, Any]] = Body(default=None),
    client: httpx.AsyncClient = Depends(get_http_client),
):
    """Simple passthrough test:
    POST <API_BASE_PATH>/details with Bearer AUTH_TOKEN.
    Returns upstream response as-is.
    """
    if not settings.API_BASE_PATH or not settings.AUTH_TOKEN:
        raise HTTPException(500, "Missing API_BASE_PATH or AUTH_TOKEN in environment.")

    try:
        resp = await client.post("/details", json=payload or {})
    except ReadTimeout:
        raise HTTPException(status_code=504, detail="Upstream timeout while calling /details")
    except httpx.HTTPError as e:
        raise HTTPException(status_code=502, detail=f"Upstream request error: {str(e)}")

    return Response(
        content=resp.content,
        status_code=resp.status_code,
        media_type=resp.headers.get("content-type", "application/octet-stream"),
    )
