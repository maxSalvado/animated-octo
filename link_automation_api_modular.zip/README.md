# Link Automation API — Modular Structure

## Structure
```
.
├─ core/
│  ├─ config.py          # Pydantic settings (env + constants, parses .env)
│  └─ deps.py            # Shared dependencies (http client provider)
├─ api/
│  └─ routes/
│     ├─ misc.py         # GET /healthz
│     ├─ spreadsheet.py  # POST /upload-extract, POST /upload-map-template (strict validation + mapping)
│     └─ integrations.py # POST /fetch-details__test (passthrough to <API_BASE_PATH>/details)
├─ service/
│  └─ ingest.py          # multi-sheet Excel ingestion via pandas/openpyxl
├─ templates/
│  └─ README.txt         # put your template file here (set B_TEMPLATE_PATH)
├─ tests/
│  └─ test_smoke.py
├─ main.py
├─ requirements.txt
└─ .env.example
```

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# edit .env to set B_TEMPLATE_PATH, TARGET_SHEET_NAME, etc.

uvicorn main:app --reload --port 8000
# http://localhost:8000/docs
```
