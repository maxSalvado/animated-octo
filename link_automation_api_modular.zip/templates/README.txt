Place your Excel template file here and set B_TEMPLATE_PATH in .env (e.g., ./templates/file_f.xlsx)
